This is the Zlib dll version 1.1.3.  It provides excellent compression for use in any program that needs to compress a file, string, or byte array, since Windows does not provide a complete compression tool in the API.  Note that the group that wrote this wrote the compression algorithms (same code as Zlib) for the PNG picture file format. 

The DLL should be installed in the System32 folder.

Home page:  http://www.info-zip.org/pub/infozip/zlib/
Get the latest DLL: http://www.winimage.com/zLibDll/